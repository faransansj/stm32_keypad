/*
 * ili9341.c
 *
 *  Created on: Dec 7, 2023
 *      Author: faran
 */

#include "main.h"
#include "ili9341.h"
#include "testimg.h"

extern SPI_HandleTypeDef hspi1;

/**utility functions **/
void ILI9341_Select()
{HAL_GPIO_WritePin(ILI9341_CS_GPIO_Port, ILI9341_CS_Pin, GPIO_PIN_RESET);}		//ILI9341_CS <- 0

void ILI9341_Unselect()
{HAL_GPIO_WritePin(ILI9341_CS_GPIO_Port, ILI9341_CS_Pin, GPIO_PIN_SET);}		//ILI9341_CS <- 1

void ILI9341_Reset()
{
	HAL_GPIO_WritePin(ILI9341_RES_GPIO_Port , ILI9341_RES_Pin, GPIO_PIN_RESET);					//ILI9341_RES <- 0
	HAL_Delay(5);		//5ms delay
	HAL_GPIO_WritePin(ILI9341_RES_GPIO_Port , ILI9341_RES_Pin, GPIO_PIN_SET);					//ILI9341_RES <- 1
	HAL_Delay(5);		//5ms delay
}

void ILI9341_WriteCommand(uint8_t cmd)
{
	HAL_GPIO_WritePin(ILI9341_DC_GPIO_Port , ILI9341_DC_Pin, GPIO_PIN_RESET);					//ILI9341_DC <- 0
	HAL_SPI_Transmit(&hspi1,&cmd,sizeof(cmd),100);								//hSPI1 1-byte command transmit
}

void ILI9341_WriteData(uint8_t * buff, size_t buff_size)
{
	  HAL_GPIO_WritePin(ILI9341_DC_GPIO_Port , ILI9341_DC_Pin, GPIO_PIN_SET);					//ILI9341_DC <- 1

	  while (buff_size>0)								//Data division transmit
	{
		uint16_t chunk_size;
		if (buff_size>65535) 							//if buff_size bigger than 65535
		{chunk_size = 65535;} 							//chunk_size <- 65535
		else
		chunk_size = buff_size; 						//if not chunk_size <- buff_size
		HAL_SPI_Transmit(&hspi1,buff,chunk_size,10);	//SPI1 chunk size buff[] transmit

		buff += chunk_size;
		buff_size -= chunk_size;
	}
}

/**ILI9341 reset function**/
void ILI9341_Init()
{
	ILI9341_Reset();
	ILI9341_Select();

	uint8_t para_data_1[] = {0x55}; 				//parameter data
	uint8_t para_data_2[] = {ILI9341_ROTATION};

	ILI9341_WriteCommand(0b00111010);	//col_mod (MCU 16 bits per pixel)
	ILI9341_WriteData(para_data_1,sizeof(para_data_1));

	ILI9341_WriteCommand(0b00110110);	//Memory access control
	ILI9341_WriteData(para_data_2,sizeof(para_data_2));

	ILI9341_WriteCommand(0b00010001);	//Sleep out
	HAL_Delay(60);						//60ms delay
	ILI9341_WriteCommand(0b00101001);	//Display On
	ILI9341_Unselect();
}

/** ILI9341 coordinate setting function**/
void ILI9341_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
	ILI9341_WriteCommand(0b00101010);	//Column Address set
	uint8_t buf_x[3];
	buf_x[0]= (x0>>8);
	buf_x[1]= x0 & 0xff;
	buf_x[2]= (x1>>8);
	buf_x[3]= x1 & 0xff;

	ILI9341_WriteData(buf_x,4);


	ILI9341_WriteCommand(0b00101011);	//ROW Address set
	uint8_t buf_y[3];
	buf_y[0]= (y0>>8);
	buf_y[1]= y0 & 0xff;
	buf_y[2]= (y1>>8);
	buf_y[3]= y1 & 0xff;

	ILI9341_WriteData(buf_y,4);

	ILI9341_WriteCommand(0b00101100);	//Memory write
}


void ILI9341_DrawPixel(uint16_t x, uint16_t y, uint16_t color) {
    uint8_t data[2];
	if((x >= ILI9341_WIDTH) || (y >= ILI9341_HEIGHT))
        return;

    ILI9341_Select();

    ILI9341_SetAddressWindow(x, y, x, y);
    data[0] = color >> 8;
    data[1] = color & 0xff;
    ILI9341_WriteData(data, sizeof(data));

    ILI9341_Unselect();
}

void ILI9341_FillRectangle(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color)
{
	static uint8_t buf[ILI9341_WIDTH*2];
	if ((x >= ILI9341_WIDTH) || (y >= ILI9341_HEIGHT))
		return;
	if ((x+w-1) >= ILI9341_WIDTH) w = ILI9341_WIDTH-x;
	if ((y+h-1) >= ILI9341_HEIGHT) h = ILI9341_HEIGHT-y;

	ILI9341_Select();

	ILI9341_SetAddressWindow(x, y, x+w-1, y+h-1);
	for(int i=0; i<w*2; i=i+2)
	{
		buf[i] 	= (color >>8)&0xff ;							// buf[] 에 color 값을 채워 넣음
		buf[i+1]= color&0xff;
	}
	for(int i=0; i<h; i++)
	{ILI9341_WriteData(buf,w*2);}						// ILI9341_WriteData()을 사용하여 buf[] 를 전송.
	ILI9341_Unselect();
}

void ILI9341_FillScreen(uint16_t color)
{ ILI9341_FillRectangle(0, 0, ILI9341_WIDTH, ILI9341_HEIGHT, color); }

/**Draw image function**/
void ILI9341_DrawImage(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t * image)
{
	if ((x >= ILI9341_WIDTH) || (y >= ILI9341_HEIGHT))
		return;
	if ((x+w-1) >= ILI9341_WIDTH)
		return;
	if ((y+h-1) >= ILI9341_HEIGHT)
		return;
	ILI9341_Select();
	ILI9341_SetAddressWindow(x, y, w, h);

	ILI9341_WriteData((uint8_t *)image ,w*h*2); //image 가 가리키는 데이터를 한꺼번에 전송.
	ILI9341_Unselect();
}

void ILI9341_InvertColors(unsigned invert)
{
	ILI9341_Select();
	// invert 값에 따라 Inversion OFF 또는 Inversion ON 을 전송
	if(invert & 0xff)
	{ILI9341_WriteCommand(0b00100001);} //inversion on
	else
	{ILI9341_WriteCommand(0b00100000);} //inversion off

	ILI9341_Unselect();

}

void ILI9341_WriteChar(uint16_t x, uint16_t y, char ch, FontDef font, uint16_t color, uint16_t bgcolor) {
    uint32_t i, b, j;

    ILI9341_SetAddressWindow(x, y, x+font.width-1, y+font.height-1);

    for(i = 0; i < font.height; i++) {
        b = font.data[(ch - 32) * font.height + i];
        for(j = 0; j < font.width; j++) {
            if((b << j) & 0x8000)  {
                uint8_t data[] = { color >> 8, color & 0xFF };
                ILI9341_WriteData(data, sizeof(data));
            } else {
                uint8_t data[] = { bgcolor >> 8, bgcolor & 0xFF };
                ILI9341_WriteData(data, sizeof(data));
            }
        }
    }
}

void ILI9341_WriteString(uint16_t x, uint16_t y, char* str, FontDef font, uint16_t color, uint16_t bgcolor) {
    ILI9341_Select();

    while(*str) {
        if(x + font.width >= ILI9341_WIDTH) {
            x = 0;
            y += font.height;
            if(y + font.height >= ILI9341_HEIGHT) {
                break;
            }

            if(*str == ' ') {
                // skip spaces in the beginning of the new line
                str++;
                continue;
            }
        }

        ILI9341_WriteChar(x, y, *str, font, color, bgcolor);
        x += font.width;
        str++;
    }

    ILI9341_Unselect();
}

void ILI9341_Test(void) {

	// Clear Screen
  ILI9341_FillScreen(ILI9341_BLACK);

  // Draw Borders
  ILI9341_FillRectangle(0, 0, ILI9341_WIDTH, 1, ILI9341_RED);
  ILI9341_FillRectangle(0, ILI9341_HEIGHT-1, ILI9341_WIDTH, 1, ILI9341_RED);

  for (unsigned y = 0; y<ILI9341_HEIGHT; y++) {
    ILI9341_DrawPixel(0, y, ILI9341_RED);
    ILI9341_DrawPixel(ILI9341_WIDTH-1, y, ILI9341_RED);
  }
  HAL_Delay(1000);

  // Draw fonts
  //ILI9341_FillScreen(ILI9341_BLACK);
  ILI9341_WriteString(0, 0, "midori_sour0216", Font_16x26, ILI9341_RED, ILI9341_BLACK);
  ILI9341_WriteString(0, 3*10, "Hello world", Font_16x26, ILI9341_GREEN, ILI9341_BLACK);
  ILI9341_WriteString(0, 3*10+3*18, "STM32", Font_16x26, ILI9341_BLUE, ILI9341_BLACK);
  HAL_Delay(1000);

  /**
  // Invert Colors
  ILI9341_InvertColors(1);
  HAL_Delay(300);

  // Normal Colors
  ILI9341_InvertColors(0);
  HAL_Delay(300);
  **/
  // Draw Bitmap
  ILI9341_DrawImage((ILI9341_WIDTH - 240) / 2, (ILI9341_HEIGHT - 240) / 2, 240, 240, (uint16_t *)test_img_240x240);
  HAL_Delay(1000);

}




